import React from 'react';
import type { Task } from '../types';
import { CheckCircle2, Circle, Clock, Flame, Pin, Timer, Trash2 } from 'lucide-react';
import { playSuccess } from '../utils/audio';
import confetti from 'canvas-confetti';

interface KanbanViewProps {
  tasks: Task[];
  onToggleComplete: (taskId: string) => void;
  onPinAsActive: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onOpenFocusModal: (task: Task) => void;
}

export const KanbanView: React.FC<KanbanViewProps> = ({
  tasks,
  onToggleComplete,
  onPinAsActive,
  onDeleteTask,
  onOpenFocusModal,
}) => {
  const activeTask = tasks.find(t => !t.completed && t.startTime) || null;
  const queuedTasks = tasks.filter(t => !t.completed && t.id !== activeTask?.id);
  const completedTasks = tasks.filter(t => t.completed);

  const handleComplete = (taskId: string) => {
    playSuccess();
    try {
      confetti({ particleCount: 35, spread: 50, origin: { y: 0.6 } });
    } catch {}
    onToggleComplete(taskId);
  };

  const renderCard = (task: Task, isHighlighted = false) => (
    <div
      key={task.id}
      className={`rounded-xl p-3 border transition-all ${
        isHighlighted
          ? 'bg-blue-950/40 border-blue-600/60 shadow-lg shadow-blue-900/20'
          : task.completed
          ? 'bg-slate-900/40 border-slate-800/60 opacity-75'
          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
      }`}
    >
      <div className="flex items-center justify-between text-[11px] mb-1.5">
        <span className="font-mono text-blue-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
          {task.startTime || `${task.durationMinutes}m`}
        </span>
        <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
          task.priority === 'urgent' ? 'bg-rose-950 text-rose-300' :
          task.priority === 'high' ? 'bg-amber-950 text-amber-300' : 'bg-slate-800 text-slate-400'
        }`}>
          {task.priority}
        </span>
      </div>

      <h5 className={`text-xs font-semibold text-slate-200 line-clamp-2 ${task.completed ? 'line-through text-slate-500' : ''}`}>
        {task.title}
      </h5>

      <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-800/80 text-xs">
        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              if (!task.completed) {
                handleComplete(task.id);
              } else {
                onToggleComplete(task.id);
              }
            }}
            className="text-slate-400 hover:text-emerald-400 p-1 rounded"
            title={task.completed ? 'Mark pending' : 'Mark complete'}
          >
            {task.completed ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Circle className="w-4 h-4" />}
          </button>
          {!task.completed && (
            <button
              onClick={() => onOpenFocusModal(task)}
              className="text-slate-400 hover:text-blue-400 p-1 rounded"
              title="Focus timer"
            >
              <Timer className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-1">
          {!task.completed && (
            <button
              onClick={() => onPinAsActive(task.id)}
              className="text-slate-400 hover:text-blue-400 p-1 rounded"
              title="Pin to Android Notification Bar"
            >
              <Pin className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => onDeleteTask(task.id)}
            className="text-slate-500 hover:text-rose-400 p-1 rounded"
            title="Delete task"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {/* Column 1: Active In-Progress / Pinned */}
      <div className="bg-slate-900/60 rounded-2xl border border-blue-900/40 p-3.5 flex flex-col">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-blue-900/40">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Active / Pinned Plan
            </h4>
          </div>
          <span className="text-[11px] font-mono font-semibold text-blue-400 bg-blue-950 px-2 py-0.5 rounded">
            {activeTask ? '1 Active' : '0'}
          </span>
        </div>

        <div className="space-y-2.5 flex-1">
          {activeTask ? (
            renderCard(activeTask, true)
          ) : (
            <div className="text-center py-8 text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
              No task currently pinned. Pick any queued task to pin to notification bar.
            </div>
          )}
        </div>
      </div>

      {/* Column 2: Queued Tasks */}
      <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-3.5 flex flex-col">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Queued Tasks
            </h4>
          </div>
          <span className="text-[11px] font-mono font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
            {queuedTasks.length}
          </span>
        </div>

        <div className="space-y-2.5 flex-1 max-h-[600px] overflow-y-auto pr-1">
          {queuedTasks.length > 0 ? (
            queuedTasks.map(t => renderCard(t))
          ) : (
            <div className="text-center py-8 text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
              No tasks waiting in queue.
            </div>
          )}
        </div>
      </div>

      {/* Column 3: Completed */}
      <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-3.5 flex flex-col">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Completed
            </h4>
          </div>
          <span className="text-[11px] font-mono font-semibold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded">
            {completedTasks.length}
          </span>
        </div>

        <div className="space-y-2.5 flex-1 max-h-[600px] overflow-y-auto pr-1">
          {completedTasks.length > 0 ? (
            completedTasks.map(t => renderCard(t))
          ) : (
            <div className="text-center py-8 text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
              Completed tasks will appear here.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
