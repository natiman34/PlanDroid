import React, { useState } from 'react';
import type { Task, TaskCategory, TaskPriority, FocusSession, Language } from '../types';
import { timeToMinutes } from '../utils/scheduler';
import {
  Clock,
  CheckCircle2,
  Circle,
  Pin,
  Timer,
  Trash2,
  Search,
  Filter,
  Flame,
  Coffee,
  Briefcase,
  Code,
  Users,
  CheckCheck,
  Calendar,
  Lock,
  Plus,
  Pencil,
  Bell,
  Sparkles,
  CalendarPlus,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { playSuccess } from '../utils/audio';
import { DailyGoalSummary } from './DailyGoalSummary';
import { t } from '../utils/i18n';

interface TimelineViewProps {
  tasks: Task[];
  focusSessions?: FocusSession[];
  dailyGoalMinutes?: number;
  onUpdateDailyGoal?: (mins: number) => void;
  lang?: Language;
  onToggleComplete: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onPinAsActive: (taskId: string) => void;
  onOpenFocusModal: (task: Task) => void;
  onClearCompleted?: () => void;
  onCreatePlan: () => void;
  onEditPlan?: (task: Task) => void;
  onQuickAddPlan?: (title: string, duration: number, category: TaskCategory) => void;
  onQuickStartTimer?: (title: string, duration: number, category: TaskCategory) => void;
}

export const TimelineView: React.FC<TimelineViewProps> = ({
  tasks = [],
  focusSessions = [],
  dailyGoalMinutes = 240,
  onUpdateDailyGoal,
  lang = 'en',
  onToggleComplete,
  onDeleteTask,
  onPinAsActive,
  onOpenFocusModal,
  onClearCompleted,
  onCreatePlan,
  onEditPlan,
  onQuickAddPlan,
  onQuickStartTimer,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');

  // Active task for starting focus from the goal widget
  const activeTask = tasks.find(t => !t.completed && t.startTime);

  // Trigger confetti burst on completion
  const handleCheck = (taskId: string, isNowCompleted: boolean) => {
    if (!isNowCompleted) {
      playSuccess();
      try {
        confetti({
          particleCount: 45,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch {
        // ignore
      }
    }
    onToggleComplete(taskId);
  };

  // Filter tasks
  const filteredTasks = tasks.filter(t => {
    if (searchQuery.trim() && !t.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (selectedCategory !== 'all' && t.category !== selectedCategory) {
      return false;
    }
    if (filterPriority !== 'all' && t.priority !== filterPriority) {
      return false;
    }
    return true;
  });

  // Sort by start time if available
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (a.startTime && b.startTime) {
      return timeToMinutes(a.startTime) - timeToMinutes(b.startTime);
    }
    if (a.startTime) return -1;
    if (b.startTime) return 1;
    return a.createdAt - b.createdAt;
  });

  // Split into Morning (<12:00), Afternoon (12:00-17:00), Evening (>=17:00)
  const morningTasks = sortedTasks.filter(t => !t.startTime || timeToMinutes(t.startTime) < 720);
  const afternoonTasks = sortedTasks.filter(t => t.startTime && timeToMinutes(t.startTime) >= 720 && timeToMinutes(t.startTime) < 1020);
  const eveningTasks = sortedTasks.filter(t => t.startTime && timeToMinutes(t.startTime) >= 1020);

  const getCategoryIcon = (category: TaskCategory) => {
    switch (category) {
      case 'deep_work': return <Code className="w-3.5 h-3.5 text-blue-400" />;
      case 'meeting': return <Users className="w-3.5 h-3.5 text-purple-400" />;
      case 'review': return <CheckCheck className="w-3.5 h-3.5 text-amber-400" />;
      case 'break': return <Coffee className="w-3.5 h-3.5 text-emerald-400" />;
      case 'admin': return <Briefcase className="w-3.5 h-3.5 text-slate-400" />;
      default: return <Clock className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const completedCount = tasks.filter(t => t.completed).length;

  const renderTaskCard = (task: Task) => {
    return (
      <div
        key={task.id}
        className={`group relative rounded-xl border p-3.5 transition-all duration-200 ${
          task.completed
            ? 'bg-slate-900/40 border-slate-800/60 opacity-65'
            : 'bg-slate-900/90 border-slate-800 hover:border-slate-700 hover:shadow-md'
        }`}
      >
        <div className="flex items-start gap-3">
          {/* Completion Checkbox */}
          <button
            onClick={() => handleCheck(task.id, task.completed)}
            aria-label={task.completed ? `Mark ${task.title} incomplete` : `Mark ${task.title} complete`}
            className="mt-0.5 text-slate-500 hover:text-emerald-400 transition cursor-pointer shrink-0"
          >
            {task.completed ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
            ) : (
              <Circle className="w-5 h-5 text-slate-500 group-hover:text-slate-300" />
            )}
          </button>

          {/* Main content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center flex-wrap gap-2 mb-1">
              {/* Scheduled timing pill */}
              <span className="font-mono text-xs font-semibold text-blue-400 bg-blue-950/60 px-2 py-0.5 rounded border border-blue-900/50 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {task.startTime && task.endTime ? `${task.startTime} - ${task.endTime}` : `${task.durationMinutes}m`}
              </span>

              {/* Fixed time badge */}
              {task.isFixedTime && (
                <span className="text-[10px] text-amber-400/90 bg-amber-950/50 px-1.5 py-0.5 rounded border border-amber-900/40 flex items-center gap-0.5">
                  <Lock className="w-2.5 h-2.5" />
                  Fixed
                </span>
              )}

              {/* Priority pill */}
              <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                task.priority === 'urgent' ? 'bg-rose-950 text-rose-300 border border-rose-800/50' :
                task.priority === 'high' ? 'bg-amber-950 text-amber-300 border border-amber-800/50' :
                'bg-slate-800 text-slate-400'
              }`}>
                {task.priority}
              </span>

              {/* Category tag */}
              <span className="text-[10px] text-slate-400 flex items-center gap-1 bg-slate-800/60 px-1.5 py-0.5 rounded">
                {getCategoryIcon(task.category)}
                {task.category.replace('_', ' ')}
              </span>
            </div>

            <h4 className={`text-sm font-semibold tracking-tight text-slate-100 ${
              task.completed ? 'line-through text-slate-400' : ''
            }`}>
              {task.title}
            </h4>

            {task.notes && (
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">{task.notes}</p>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1 shrink-0">
            {!task.completed && (
              <>
                {/* Pin to notifications */}
                <button
                  onClick={() => onPinAsActive(task.id)}
                  aria-label={`Show ${task.title} in notification bar`}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-blue-400 hover:bg-slate-800 transition cursor-pointer"
                  title="Show in Notification Bar"
                >
                  <Bell className="w-4 h-4 text-blue-400" />
                </button>

                {/* Edit plan */}
                {onEditPlan && (
                  <button
                    onClick={() => onEditPlan(task)}
                    aria-label={`Edit plan ${task.title}`}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
                    title="Edit Plan"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                )}

                {/* Focus Timer */}
                <button
                  onClick={() => onOpenFocusModal(task)}
                  aria-label={`Open Focus Timer for ${task.title}`}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition cursor-pointer"
                  title="Launch Focus Timer"
                >
                  <Timer className="w-4 h-4 text-emerald-400" />
                </button>
              </>
            )}
            <button
              onClick={() => onDeleteTask(task.id)}
              aria-label={`Delete plan ${task.title}`}
              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition cursor-pointer"
              title="Delete Plan"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full space-y-4">
      {/* DailyGoalSummary ALWAYS at top of TimelineView */}
      <DailyGoalSummary
        tasks={tasks}
        focusSessions={focusSessions}
        dailyGoalMinutes={dailyGoalMinutes}
        onUpdateDailyGoal={onUpdateDailyGoal}
        lang={lang}
        onOpenActiveFocus={activeTask ? () => onOpenFocusModal(activeTask) : undefined}
      />

      {/* When no plans exist, render clean Empty State directly beneath DailyGoalSummary */}
      {tasks.length === 0 ? (
        <div className="text-center py-14 px-6 rounded-3xl border border-dashed border-slate-800 bg-slate-900/40 space-y-4 animate-in fade-in">
          <div className="w-16 h-16 rounded-2xl bg-blue-600/10 text-blue-400 border border-blue-500/20 flex items-center justify-center mx-auto">
            <CalendarPlus className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-100">{t('noPlansYet', lang)}</h3>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-md mx-auto leading-relaxed">
              {t('noPlansDesc', lang)}
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                onCreatePlan();
              }}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-blue-600/25 transition active:scale-95 cursor-pointer inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>{t('createPlan', lang)}</span>
            </button>
          </div>

          {/* Quick starter chips */}
          {(onQuickStartTimer || onQuickAddPlan) && (
            <div className="pt-4 border-t border-slate-800/80 max-w-sm mx-auto">
              <span className="text-[11px] text-slate-500 block mb-2 font-medium">{t('quickStartWith', lang)}</span>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                <button
                  onClick={() => {
                    if (onQuickStartTimer) {
                      onQuickStartTimer('Deep Work Session', 45, 'deep_work');
                    } else if (onQuickAddPlan) {
                      onQuickAddPlan('Deep Work Session', 45, 'deep_work');
                    }
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700/60 transition cursor-pointer"
                >
                  {t('quickDeepWork', lang)}
                </button>
                <button
                  onClick={() => {
                    if (onQuickStartTimer) {
                      onQuickStartTimer('Team Sync / Call', 30, 'meeting');
                    } else if (onQuickAddPlan) {
                      onQuickAddPlan('Team Sync / Call', 30, 'meeting');
                    }
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700/60 transition cursor-pointer"
                >
                  {t('quickSync', lang)}
                </button>
                <button
                  onClick={() => {
                    if (onQuickStartTimer) {
                      onQuickStartTimer('Coffee Recharge', 15, 'break');
                    } else if (onQuickAddPlan) {
                      onQuickAddPlan('Coffee Recharge', 15, 'break');
                    }
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700/60 transition cursor-pointer"
                >
                  {t('quickBreak', lang)}
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Header bar with Search, Filters, and Create Plan Button */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('searchPlansPlaceholder', lang)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* Category filter */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
              >
                <option value="all">{t('allCategories', lang)}</option>
                <option value="deep_work">Deep Work</option>
                <option value="meeting">Meetings</option>
                <option value="review">Reviews</option>
                <option value="break">Breaks</option>
                <option value="admin">Admin</option>
              </select>

              {/* Priority filter */}
              <select
                value={filterPriority}
                onChange={(e) => setFilterPriority(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
              >
                <option value="all">{t('allPriorities', lang)}</option>
                <option value="urgent">Urgent</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>

              {/* Clear Completed Button */}
              {onClearCompleted && completedCount > 0 && (
                <button
                  onClick={onClearCompleted}
                  className="px-2.5 py-2 bg-slate-900 hover:bg-rose-950/30 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-900/50 rounded-xl text-xs font-medium transition cursor-pointer whitespace-nowrap"
                  title="Remove all completed plans from schedule"
                >
                  {t('clearCompleted', lang)} ({completedCount})
                </button>
              )}

              {/* Create Plan Button */}
              <button
                onClick={() => {
                  onCreatePlan();
                }}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-sm transition active:scale-95 cursor-pointer whitespace-nowrap flex items-center gap-1.5 ml-auto"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t('createPlan', lang)}</span>
              </button>
            </div>
          </div>

          {/* Quick-Start Timer Action Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
            <span className="text-[11px] text-slate-400 font-medium whitespace-nowrap flex items-center gap-1 shrink-0">
              <Zap className="w-3 h-3 text-amber-400" />
              {t('quickStartWith', lang)}
            </span>
            <button
              onClick={() => {
                if (onQuickStartTimer) onQuickStartTimer('Deep Work Session', 45, 'deep_work');
                else if (onQuickAddPlan) onQuickAddPlan('Deep Work Session', 45, 'deep_work');
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] font-medium border border-slate-800 hover:border-indigo-500/50 transition cursor-pointer whitespace-nowrap active:scale-95"
            >
              {t('quickDeepWork', lang)}
            </button>
            <button
              onClick={() => {
                if (onQuickStartTimer) onQuickStartTimer('Team Sync / Call', 30, 'meeting');
                else if (onQuickAddPlan) onQuickAddPlan('Team Sync / Call', 30, 'meeting');
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] font-medium border border-slate-800 hover:border-blue-500/50 transition cursor-pointer whitespace-nowrap active:scale-95"
            >
              {t('quickSync', lang)}
            </button>
            <button
              onClick={() => {
                if (onQuickStartTimer) onQuickStartTimer('Coffee Recharge', 15, 'break');
                else if (onQuickAddPlan) onQuickAddPlan('Coffee Recharge', 15, 'break');
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] font-medium border border-slate-800 hover:border-emerald-500/50 transition cursor-pointer whitespace-nowrap active:scale-95"
            >
              {t('quickBreak', lang)}
            </button>
          </div>

          {/* Timeline Segments */}
          {sortedTasks.length === 0 ? (
            <div className="text-center py-10 px-4 rounded-2xl border border-dashed border-slate-800 bg-slate-900/30">
              <Calendar className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <h4 className="text-sm font-semibold text-slate-300">No matching plans</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Try adjusting your search query or filter.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Morning Segment */}
              {morningTasks.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      {t('morningBlock', lang)}
                    </h3>
                    <span className="text-[11px] text-slate-500">({morningTasks.length} {t('plansPlural', lang)})</span>
                  </div>
                  <div className="space-y-2.5 border-l-2 border-slate-800 pl-3 ml-1">
                    {morningTasks.map(renderTaskCard)}
                  </div>
                </div>
              )}

              {/* Lunch Interval Highlight */}
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/50 border border-dashed border-emerald-900/50 text-xs text-emerald-400/90">
                <Coffee className="w-4 h-4 text-emerald-400" />
                <span>{t('optimalLunchWindow', lang)}</span>
              </div>

              {/* Afternoon Segment */}
              {afternoonTasks.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="w-2 h-2 rounded-full bg-blue-400" />
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      {t('afternoonBlock', lang)}
                    </h3>
                    <span className="text-[11px] text-slate-500">({afternoonTasks.length} {t('plansPlural', lang)})</span>
                  </div>
                  <div className="space-y-2.5 border-l-2 border-slate-800 pl-3 ml-1">
                    {afternoonTasks.map(renderTaskCard)}
                  </div>
                </div>
              )}

              {/* Evening Segment */}
              {eveningTasks.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="w-2 h-2 rounded-full bg-purple-400" />
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      {t('eveningBlock', lang)}
                    </h3>
                    <span className="text-[11px] text-slate-500">({eveningTasks.length} {t('plansPlural', lang)})</span>
                  </div>
                  <div className="space-y-2.5 border-l-2 border-slate-800 pl-3 ml-1">
                    {eveningTasks.map(renderTaskCard)}
                  </div>
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
};
