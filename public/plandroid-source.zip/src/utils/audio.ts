import type { AlarmSound } from '../types';

// 100% offline Web Audio API sound synthesizer
let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Play configurable alarm sound when a focus timer completes
 */
export function playAlarmSound(sound: AlarmSound = 'bell', volume = 0.8) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const safeVol = Math.max(0.05, Math.min(1, volume));
    const now = ctx.currentTime;

    switch (sound) {
      case 'digital': {
        // Digital 3-beep alarm pattern: beep-beep-beep
        [0, 0.22, 0.44].forEach((offset) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'square';
          osc.frequency.setValueAtTime(880, now + offset); // A5

          gain.gain.setValueAtTime(0.001, now + offset);
          gain.gain.linearRampToValueAtTime(0.25 * safeVol, now + offset + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.16);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + offset);
          osc.stop(now + offset + 0.16);
        });
        break;
      }

      case 'harp': {
        // Gentle relaxing harp arpeggio (Pentatonic: C5, D5, E5, G5, A5, C6)
        const notes = [523.25, 587.33, 659.25, 783.99, 880.00, 1046.50];
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const start = now + idx * 0.1;

          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, start);

          gain.gain.setValueAtTime(0.001, start);
          gain.gain.linearRampToValueAtTime(0.22 * safeVol, start + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.8);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(start);
          osc.stop(start + 0.8);
        });
        break;
      }

      case 'chime': {
        // Dual harmonic chime
        [587.33, 880, 1174.66].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const start = now + idx * 0.12;

          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, start);

          gain.gain.setValueAtTime(0.001, start);
          gain.gain.linearRampToValueAtTime(0.25 * safeVol, start + 0.04);
          gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.9);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(start);
          osc.stop(start + 0.9);
        });
        break;
      }

      case 'bell':
      default: {
        // Resonant meditation bell with multiple harmonic partials
        const fundamental = 440; // A4
        const partials = [
          { mult: 1.0, gain: 0.35, decay: 1.4 },
          { mult: 2.0, gain: 0.20, decay: 1.1 },
          { mult: 3.01, gain: 0.15, decay: 0.8 },
          { mult: 4.16, gain: 0.08, decay: 0.5 },
        ];

        partials.forEach((p) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(fundamental * p.mult, now);

          gain.gain.setValueAtTime(0.001, now);
          gain.gain.linearRampToValueAtTime(p.gain * safeVol, now + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + p.decay);

          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + p.decay);
        });
        break;
      }
    }
  } catch {
    // Audio context may be restricted before user gesture
  }
}

let activeAlarmInterval: NodeJS.Timeout | null = null;

/**
 * Starts repeating alarm sound loop that fires until explicitly stopped (snooze/dismiss)
 * - repeatSeconds === 0: Sustained continuous pulsing (every 2.5s)
 * - repeatSeconds === -1: Play once only
 * - repeatSeconds > 0: Repeat at the specified second interval (15s, 30s, 60s, etc.)
 */
export function startAlarmLoop(sound: AlarmSound = 'bell', volume = 0.8, repeatSeconds = 0) {
  stopAlarmLoop();
  
  // Play initial alarm chime immediately
  playAlarmSound(sound, volume);

  // If -1, user selected "play once only"
  if (repeatSeconds === -1) {
    return;
  }

  // 0 means sustained continuous alarm pulse (every 2.5 seconds)
  const intervalMs = repeatSeconds === 0 ? 2500 : Math.max(5, repeatSeconds) * 1000;

  activeAlarmInterval = setInterval(() => {
    playAlarmSound(sound, volume);
  }, intervalMs);
}

/**
 * Stops any active repeating alarm loop
 */
export function stopAlarmLoop() {
  if (activeAlarmInterval) {
    clearInterval(activeAlarmInterval);
    activeAlarmInterval = null;
  }
}

export function isAlarmLoopActive(): boolean {
  return activeAlarmInterval !== null;
}

/**
 * 1-minute warning tone: distinct dual-beep alerting the user that 60s remain
 */
export function playOneMinuteWarning(volume = 0.6) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const safeVol = Math.max(0.05, Math.min(1, volume));

    // Two rapid crisp tones (659Hz -> 880Hz)
    [
      { freq: 659.25, time: now },
      { freq: 880.0, time: now + 0.15 },
    ].forEach(({ freq, time }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, time);

      gain.gain.setValueAtTime(0.001, time);
      gain.gain.linearRampToValueAtTime(0.25 * safeVol, time + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.12);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(time);
      osc.stop(time + 0.12);
    });
  } catch {
    // ignore
  }
}

// Ordinary UI chime removed - interactions respond silently
export function playChime() {
  // Silent: ordinary UI interaction sounds removed
}

// Upbeat celebration arpeggio when a task is completed (task completion chime)
export function playSuccess() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const start = now + idx * 0.08;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, start);

      gain.gain.setValueAtTime(0.01, start);
      gain.gain.linearRampToValueAtTime(0.2, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(start);
      osc.stop(start + 0.35);
    });
  } catch {
    // ignore
  }
}

// Button and UI click sounds removed - all buttons and controls respond silently
export function playTick() {
  // Silent: all button-clicking and tap audio removed
}
